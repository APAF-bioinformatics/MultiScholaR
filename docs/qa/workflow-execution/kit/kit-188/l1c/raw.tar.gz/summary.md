### Tests (head): 0 files; passed 0, failed 0, errors 0, skipped 0; ok 0, failed 0, timeout 0, crashed 0

| file | passed | failed | errors | skipped | warnings | seconds | status |
|---|---:|---:|---:|---:|---:|---:|---|

### Scripts
| # | path | exit | seconds | status |
|---:|---|---:|---:|---|
| 1 | docs/qa/workflow-execution/kit/kit-188/e16/run-e16.R | 0 | 456 | ok |
| 2 | docs/qa/workflow-execution/kit/kit-188/sim-k188.R | 2 | 109 | failed |

**Run outcome: failure** (a head file crashed or timed out, or a script failed)
