### Tests (head): 0 files; passed 0, failed 0, errors 0, skipped 0; ok 0, failed 0, timeout 0, crashed 0

| file | passed | failed | errors | skipped | warnings | seconds | status |
|---|---:|---:|---:|---:|---:|---:|---|

### Scripts
| # | path | exit | seconds | status |
|---:|---|---:|---:|---|
| 1 | docs/qa/workflow-execution/kit/kit-188/sim-k188.R | 0 | 9709 | ok |

**Run outcome: success** (every head file ran to completion; failing expectations, if any, are in the tables)
